<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="space-y-3 pt-3">
        <div class="px-3 flex gap-3">
            <div>
                <button class="cp-1 text-sm rounded-lg p-3 font-bold" data-modal-target="addKategoriModal"
                    data-modal-toggle="addKategoriModal">Tambah Kategori</button>
            </div>
            <?php echo $__env->make('components.modal.add.add-kategori', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div>
                <button class="cp-1 text-sm rounded-lg p-3 font-bold" data-modal-target="addDomainModal"
                    data-modal-toggle="addDomainModal">Tambah Domain</button>
            </div>
            <?php echo $__env->make('components.modal.add.add-domain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="px-3">
            <div class="mb-4 border-b border-gray-200 dark:border-gray-700">
                <ul class="flex flex-wrap -mb-px text-sm font-medium text-center" id="myTab"
                    data-tabs-toggle="#myTabContent" role="tablist">
                    <li class="mr-2" role="presentation">
                        <button class="inline-block p-4 border-b-2 rounded-t-lg" id="list-kategori-tab"
                            data-tabs-target="#tabs-list-kategori" type="button" role="tab"
                            aria-controls="list-kategori" aria-selected="false">
                            Daftar Kategori</button>
                    </li>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mr-2" role="presentation">
                            <button class="inline-block p-4 border-b-2 rounded-t-lg" id="<?php echo e($item->id); ?>-tab"
                                data-tabs-target="#tabs-<?php echo e($item->id); ?>" type="button" role="tab"
                                aria-controls="<?php echo e($item->id); ?>" aria-selected="false">
                                <?php echo e($item->nama_kategori); ?></button>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div id="myTabContent">
                <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800 space-y-2" id="tabs-list-kategori"
                    role="tabpanel" aria-labelledby="list-kategori-tab">
                    <div id="accordion-kategori">
                        <div id="accordion-open" data-accordion="open" class="space-y-2">
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h2 id="accordion-open-heading-<?php echo e($item->id); ?>">
                                    <button type="button"
                                        class="flex items-center justify-between w-full p-3 rounded-lg font-medium rtl:text-right text-gray-500 border border-gray-200 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-800 dark:border-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 gap-3"
                                        data-accordion-target="#accordion-open-body-<?php echo e($item->id); ?>"
                                        aria-expanded="false" aria-controls="accordion-open-body-<?php echo e($item->id); ?>">
                                        <span class="flex items-center gap-2 w-full">
                                            <p>
                                                <?php echo e($loop->index + 1); ?>.
                                            </p>
                                            <input type="text"
                                                class="w-full leading-none p-0 border-none bg-transparent nama_kategori focus:ring-0 select-none"
                                                value="<?php echo e($item->nama_kategori); ?>"
                                                data-kategori-id="<?php echo e($item->id); ?>" readonly="true"
                                                ondblclick="this.readOnly='';">
                                        </span>
                                    </button>
                                </h2>
                                <div id="accordion-open-body-<?php echo e($item->id); ?>" class="hidden"
                                    aria-labelledby="accordion-open-heading-<?php echo e($item->id); ?>">
                                    <div class="p-3 border rounded-lg mt-2 border-gray-200 dark:border-gray-700">
                                        <div class="rounded-lg overflow-hidden">
                                            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                                <thead
                                                    class="text-xs text-gray-700 uppercase cp-1 dark:bg-gray-700 dark:text-gray-400">
                                                    <tr>
                                                        <th scope="col" class="px-6 py-3">
                                                            No
                                                        </th>
                                                        <th scope="col" class="px-6 py-3">
                                                            Nama Domain
                                                        </th>
                                                        <th scope="col" class="px-6 py-3">
                                                            User
                                                        </th>
                                                        <th scope="col" class="px-6 py-3">
                                                            Status Generate
                                                        </th>
                                                        <th scope="col" class="px-6 py-3">
                                                            Status Sitemap
                                                        </th>
                                                        <th scope="col" class="px-6 py-3 text-center">
                                                            Action
                                                        </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $item->domain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr
                                                            class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                                            <th scope="row"
                                                                class="px-6 py-4 font-medium text-gray-900 dark:text-white">
                                                                <?php echo e($loop->index + 1); ?>

                                                            </th>
                                                            <td class="px-6 py-4">
                                                                <?php echo e($items->nama_domain); ?>

                                                            </td>
                                                            <td class="px-6 py-4 whitespace-nowrap">
                                                                <?php if($items->user): ?>
                                                                    <?php echo e($items->user->name); ?>

                                                                <?php endif; ?>
                                                            </td>
                                                            <td class="px-6 py-4 whitespace-nowrap">
                                                                <select
                                                                    class="border-none focus:ring-0 bg-transparent text-sm status_keterangan"
                                                                    data-domain-id="<?php echo e($items->id); ?>">
                                                                    <option value="Running"
                                                                        <?php if($items->status_keterangan == 'Running'): ?> selected <?php endif; ?>>
                                                                        Running</option>
                                                                    <option value="Done"
                                                                        <?php if($items->status_keterangan == 'Done'): ?> selected <?php endif; ?>>
                                                                        Done</option>
                                                                </select>
                                                            </td>
                                                            <td class="px-6 py-4 whitespace-nowrap">
                                                                <select
                                                                    class="border-none focus:ring-0 bg-transparent text-sm status_sitemap"
                                                                    data-domain-id="<?php echo e($items->id); ?>">
                                                                    <option value="Undone"
                                                                        <?php if($items->status_sitemap == 'Undone'): ?> selected <?php endif; ?>>
                                                                        Undone</option>
                                                                    <option value="Done"
                                                                        <?php if($items->status_sitemap == 'Done'): ?> selected <?php endif; ?>>
                                                                        Done</option>
                                                                </select>
                                                            </td>
                                                            <td class="px-6 py-4 ">
                                                                <div
                                                                    class="font-medium text-blue-600 dark:text-blue-500 flex items-center justify-center gap-3">
                                                                    <button class=""
                                                                        data-modal-target="editDomain-<?php echo e($items->id); ?>"
                                                                        data-modal-toggle="editDomain-<?php echo e($items->id); ?>">
                                                                        Edit
                                                                    </button>
                                                                    <?php if (isset($component)) { $__componentOriginald513b6d74d001ea66d1ad4a85e1ce1f7 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.edit.edit-domain','data' => ['domain' => $items,'kategori' => $kategori,'user' => $user]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.edit.edit-domain'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['domain' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($items),'kategori' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kategori),'user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald513b6d74d001ea66d1ad4a85e1ce1f7)): ?>
<?php $component = $__componentOriginald513b6d74d001ea66d1ad4a85e1ce1f7; ?>
<?php unset($__componentOriginald513b6d74d001ea66d1ad4a85e1ce1f7); ?>
<?php endif; ?>
                                                                    <form
                                                                        action="<?php echo e(route('domain.destroy', $items->id)); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button class="text-red-600">
                                                                            Delete
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="hidden p-4 rounded-lg bg-gray-50 dark:bg-gray-800" id="tabs-<?php echo e($item->id); ?>"
                        role="tabpanel" aria-labelledby="<?php echo e($item->id); ?>-tab">
                        <div class="flex gap-2 justify-between pb-2">
                            <div class="flex items-center gap-2 justify-center w-full">
                                <div class="w-3 h-3 bg-blue-600"></div>
                                <p>Running</p>
                            </div>
                            <div class="flex items-center gap-2 justify-center w-full">
                                <div class="w-3 h-3 bg-green-600"></div>
                                <p>Done</p>
                            </div>
                        </div>
                        <div class="grid grid-cols-5 gap-3">
                            <?php $__currentLoopData = $domain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($items->kategori_id == $item->id): ?>
                                    <div
                                        class="border h-20 rounded-lg  <?php if($items->status_keterangan == 'Running'): ?> running <?php elseif($items->status_keterangan == 'Done'): ?> done <?php endif; ?> relative">
                                        <button data-modal-target="editDomain2-<?php echo e($items->id); ?>"
                                            data-modal-toggle="editDomain2-<?php echo e($items->id); ?>"
                                            class=" w-full text-center h-full p-3   ">
                                            <p class="truncate font-extrabold text-xl text-start leading-1">
                                                <?php echo e($items->nama_domain); ?>

                                            </p>
                                            <?php if($items->user): ?>
                                                <p
                                                    class="truncate font-extrabold text-start text-sm leading-none text-gray-200">
                                                    <?php echo e($items->user->name); ?>

                                                </p>
                                            <?php endif; ?>
                                        </button>
                                        <?php if (isset($component)) { $__componentOriginal1f25b1033c40c2018fd8183d8c4e5af8 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal.edit.edit-domain2','data' => ['domain' => $items,'kategori' => $kategori,'user' => $user]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal.edit.edit-domain2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['domain' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($items),'kategori' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kategori),'user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f25b1033c40c2018fd8183d8c4e5af8)): ?>
<?php $component = $__componentOriginal1f25b1033c40c2018fd8183d8c4e5af8; ?>
<?php unset($__componentOriginal1f25b1033c40c2018fd8183d8c4e5af8); ?>
<?php endif; ?>
                                        <div class="absolute top-2 right-2 rounded flex gap-1">
                                            <?php if($items->report): ?>
                                                <a href="//<?php echo e($items->report); ?>" target="_blank" title="Link Report"
                                                    class="hover:bg-white hover:bg-opacity-25 rounded-lg">
                                                    <svg width="20" height="20" viewBox="0 0 21 21"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g id="Interface / External_Link">
                                                            <path id="Vector"
                                                                d="M10.0002 5H8.2002C7.08009 5 6.51962 5 6.0918 5.21799C5.71547 5.40973 5.40973 5.71547 5.21799 6.0918C5 6.51962 5 7.08009 5 8.2002V15.8002C5 16.9203 5 17.4801 5.21799 17.9079C5.40973 18.2842 5.71547 18.5905 6.0918 18.7822C6.5192 19 7.07899 19 8.19691 19H15.8031C16.921 19 17.48 19 17.9074 18.7822C18.2837 18.5905 18.5905 18.2839 18.7822 17.9076C19 17.4802 19 16.921 19 15.8031V14M20 9V4M20 4H15M20 4L13 11"
                                                                stroke="#ffffff" stroke-width="2"
                                                                stroke-linecap="round" stroke-linejoin="round" />
                                                        </g>
                                                    </svg>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>
    $(document).ready(function() {
        $('.nama_kategori').on('input', function() {
            var namaKategori = $(this).val();
            var kategoriId = $(this).data('kategori-id');
            loading.style.display = 'block';
            const tab = document.getElementById(kategoriId + '-tab');
            tab.textContent = namaKategori;
            $.ajax({
                url: '/kategoris/nama-kategori',
                method: 'PUT',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    kategori: kategoriId,
                    nama_kategori: namaKategori
                },
                success: function(response) {
                    console.log(response);
                    loading.style.display = 'none';
                },
                error: function(error) {}
            });
        });
        $('.status_keterangan').on('change', function() {
            var status = $(this).val();
            var domainId = $(this).data('domain-id');
            loading.style.display = 'block';
            $.ajax({
                url: '/domains/status-keterangan',
                method: 'PUT',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    domain: domainId,
                    status_keterangan: status
                },
                success: function(response) {
                    console.log(response);
                    loading.style.display = 'none';
                },
                error: function(error) {}
            });
        });
        $('.status_sitemap').on('change', function() {
            var status = $(this).val();
            var domainId = $(this).data('domain-id');
            loading.style.display = 'block';
            $.ajax({
                url: '/domains/status-sitemap',
                method: 'PUT',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    domain: domainId,
                    status_sitemap: status
                },
                success: function(response) {
                    console.log(response);
                    loading.style.display = 'none';
                },
                error: function(error) {}
            });
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\webGuardian\resources\views/dashboard.blade.php ENDPATH**/ ?>